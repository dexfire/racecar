#!/bin/bash

#for run artrobot
#Steven.Zhang
#2018.03.09

ssh sz@192.168.5.101



