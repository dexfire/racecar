#include <ros/ros.h>
#include <sstream>
#include <nav_msgs/Odometry.h>
#include <tf/transform_listener.h>
#include <tf/transform_datatypes.h>
#include <sensor_msgs/LaserScan.h>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/videoio.hpp>    
#include <opencv2/opencv.hpp>
#include <cv_bridge/cv_bridge.h>
#include <stdio.h>
#include <iostream>
#include <map>
#include <time.h>
#include <cmath>
#include <geometry_msgs/Point.h>

using namespace cv;
using namespace std;
sensor_msgs::LaserScan laser;
geometry_msgs::Point  obstacle;
Mat my_map,area;
int cnt=0; 
ros::Subscriber laser_sub,odom_sub;
ros::Publisher pub;
double towards,at_x,at_y;
double obstacle_x[15],obstacle_y[15];
double obstacle_distance;
int obstacle_num = 0;
bool have_obstacle = false ;

double getYaw(const geometry_msgs::Pose& carPose)
{
    float x = carPose.orientation.x;
    float y = carPose.orientation.y;
    float z = carPose.orientation.z;
    float w = carPose.orientation.w;

    double tmp,yaw;
    tf::Quaternion q(x,y,z,w);
    tf::Matrix3x3 quaternion(q);
    quaternion.getRPY(tmp,tmp, yaw);

    return yaw;
}
void odomCB(const nav_msgs::Odometry odomMsg)
{
    towards = getYaw(odomMsg.pose.pose);
    //if(towards>-1.57&&towards<1.57){
	//towards = 0; 
	//}
    //else {
	//towards = 3.14;
	//}
    at_x = odomMsg.pose.pose.position.x;
    at_y = odomMsg.pose.pose.position.y;
    cout<<"towards "<<towards<<endl;
}


bool ifInArea(double angle, double distance)
{
    int x,y,y_min = -1000,y_max = 1000;
    //cout<<"angle: "<<angle<<" dis:"<<distance<<endl;
    angle = angle/180.0*3.1415926 + towards;
    x = distance*20.0*sin(angle)+at_x+40; //\u56de\u7a0bangle\u5e94\u8be5\u4e3a\u8d1f(angle\u53d6\u503c-180\u5230180)
    y = -(distance*20.0*cos(angle))+at_y+100;
    //cout<<"Car at x:"<<at_x<<" y:"<<at_y<<" towards :"<<towards<<endl;
    //cout<<"Point at x:"<<x<<" y:"<<y<<" angle :"<<angle<<endl;
    if(my_map.at<uchar>(y, x) < 250)
    	return false;
    for(int i=0;i<30;i++){ //\u5de6\u53f31.5m
        if(my_map.at<uchar>(y-i, x) < 10 && y-i > y_min)
            y_min = y-i;
        if(my_map.at<uchar>(y+i, x) < 10 && y+i < y_max)
            y_max = y+i;
    }
    if(y_min == -1000 || y_max == 1000)
    	return false;
    cout<<"ymin: "<<y_min<<" ymax: "<<y_max<<endl;	
    if(y_max - y < 5 && y - y_min < 5)
        return false;
    return true;
}

void laserCB(const sensor_msgs::LaserScan::ConstPtr& laserMsg)
{
    map<int,int>  points;
    laser = *laserMsg;
    cnt = 50;
    int in = 0,start = 0,obstacle_point = 0;
    int num = 0;
    int j,k,hei,px=50;
    double xl,yl,angle;
    
    laser.ranges[180] = laser.ranges[90];
    for(int i = 120; i>=60;i--){
        if(i <= 89)
            j = i +270;
        else
            j = i - 90;
        laser.ranges[i] = laser.ranges[j];
        //if(laser.ranges[j]<3){
            //cout<<"j: "<<j<<endl;
        //}
	    //angle = i/180.0*3.1415926 + towards;
        //xl = laser.ranges[i]*cos(angle);
        //yl = abs(laser.ranges[i]*sin(angle));
        //if(yl > 6 || yl < 0 || xl > 2 || xl < -2)
            //continue;
        if(laser.ranges[j] < 4.5 && laser.ranges[i+1] - laser.ranges[i] > 0.4){
            in = 1;
            start = i;
            continue;
        }
        k=j-1;
        if(k<0){
            k=359;}
        if(in ==1 && laser.ranges[j] < 4.5 && laser.ranges[k] - laser.ranges[j] > 0.4){ 
            in = 0;
            if(abs(i - start) > (0.15*360/(2*laser.ranges[i]*3.1415926))+2)
               continue;
            if(!((ifInArea(i,laser.ranges[i])) && ifInArea(start,laser.ranges[start])))
                continue;
            points[start] = laser.ranges[j];
            cout<<"start: "<<start<<" end: "<<i<<" len: "<<laser.ranges[j]<<endl;
	        obstacle_point = (i+start)/2;
            angle = obstacle_point/180.0*3.1415926 + towards;
            obstacle.x = laser.ranges[obstacle_point]*sin(angle)+at_x; 
            obstacle.y = -(laser.ranges[obstacle_point]*cos(angle)+at_y);
            //obstacle_distance = fabs((obstacle.x - obstacle_x[obstacle_num])*(obstacle.x - obstacle_x[obstacle_num])+
            //(obstacle.y - obstacle_y[obstacle_num])*(obstacle.x - obstacle_y[obstacle_num]));
            //if(obstacle_distance > 0.5){
	            //obstacle_num ++;
	            //obstacle_x [obstacle_num] = obstacle.x;
	            //obstacle_y [obstacle_num] = obstacle.y;
            //}
            // obstacle.x = obstacle_x [obstacle_num];
            //obstacle.y = obstacle_y [obstacle_num];
            if(obstacle.y>-0.2&&obstacle.y<0.2&&obstacle.x<8)
            {
            	num ++;
                cout<<"towards: "<< towards <<endl;
            }
            
	    //cout<<"x: "<<at_x<<" y: "<<at_y<<endl;
        }  
    }
    if(num == 0){
	    obstacle.x = 0.0; 
	    obstacle.y = 0.0;
    }
    pub.publish(obstacle);
    //cout<<"obstacle_num: "<<obstacle_num<<endl;
}
int main(int argc, char** argv)
{
  ros::init(argc, argv, "laser_judge_obstacle");
  ros::NodeHandle nh;
  ros::Timer timer;
  my_map = imread("/home/sz/racecar/src/art_racecar/map/test.pgm");
  my_map = my_map(Rect(1960, 1900, 600, 200));
  imwrite("/home/sz/bbb.png",my_map);
  cvtColor(my_map,my_map,COLOR_BGR2GRAY);
  laser_sub = nh.subscribe("/scan", 1, laserCB);
  odom_sub = nh.subscribe("/odometry/filtered", 1,odomCB);
  pub = nh.advertise<geometry_msgs::Point>("/obstacle", 1);
  //timer = nh.createTimer(ros::Duration(0.05),&cam); //20Hz
  cout<<"Done init, running"<<endl;
  ros::spin();
}
