#include "Solve_speed.h"
#include "PID.h"
#include "ros/ros.h"
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <iostream>

extern  PID  pid_speed;
int start_loop_flag = 0;

using namespace std; 

Solve_speed::Solve_speed()
{
    ros::NodeHandle pn("~");

    pn.param("maxspeed",max_speed,1600.0);
    pn.param("base_speed",base_speed,1560.0);
}
void Solve_speed::Speed_transform(geometry_msgs::Twist twist_msg,geometry_msgs::Twist& car_speed, nav_msgs::Odometry odom)
{
    float u=twist_msg.linear.x - odom.twist.twist.linear.x;
    car_speed.linear.x += PIDCal(&pid_speed,u);
}

int Solve_speed::accelerate_start(geometry_msgs::Twist& car_speed)
{    
    if(start_loop_flag++ <= 10)
                {                    
                    car_speed.linear.x = base_speed;
                     base_speed += 4;
                     if(car_speed.linear.x > max_speed)   
                        car_speed.linear.x = max_speed;
		    		    cout << "send_speed" << car_speed.linear.x <<"  ";
		    return 0;
                }
	return 1;
}
