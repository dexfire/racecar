#ifndef SOLVE_SPEED_H
#define	SOLVE_SPEED_H

#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
class Solve_speed
{
public:
    Solve_speed();
    void Speed_transform(geometry_msgs::Twist twist_msg,geometry_msgs::Twist& car_speed, nav_msgs::Odometry odom);
    int accelerate_start(geometry_msgs::Twist& car_speed);
    double base_speed,max_speed;
};

#endif
