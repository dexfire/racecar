#include "PID.h"
#include <iostream>
#include <ros/ros.h>
PID pid_speed;
double out=0;
void PIDInit (struct PID *pp){
    ros::NodeHandle pn("~");

    pn.param("P",pp->Proportion,15.0);
    pn.param("I",pp->Int,2.0); 
    pn.param("D",pp->Derivative,0.0);       
    pp->LastError=0;
    pp->PreError=0;
	                
}

double PIDCal(struct PID *pp, double ThisError){ 
    PIDInit(pp);
    out=pp->Proportion*(ThisError-pp->LastError)+pp->Int*ThisError
	+pp->Derivative*(ThisError-2*pp->LastError+pp->PreError);
	//out=out>20?20:out;
    pp->PreError = pp->LastError;
    pp->LastError = ThisError;    
    ROS_INFO("out=%.2f\tthisError=%.2flastError=%.2f\t",out,ThisError, pp->LastError);
    return out;
}
