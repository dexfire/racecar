#include "PID.h"
#include <iostream>
#include <ros/ros.h>
PID pid_speed;
double out=0;
void PIDInit (struct PID *pp){        
    pp->Proportion=7;         
    pp->Int=5;            
    pp->Derivative=2;
	pp->LastError=0;
	pp->PreError=0;
	                
}

double PIDCal(struct PID *pp, double ThisError){ 
    PIDInit(pp);
    out=pp->Proportion*(ThisError-pp->LastError)+pp->Int*ThisError
	+pp->Derivative*(ThisError-2*pp->LastError+pp->PreError);
    ROS_INFO("out=%.2f",out);
    return out;
}
