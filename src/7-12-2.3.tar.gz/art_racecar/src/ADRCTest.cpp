#include <iostream>
#include "ros/ros.h"
#include "ADRC.h"
#include <geometry_msgs/Vector3.h> 
#include <cstdlib>
#include <ctime>
using namespace std;
class Test
{
public:
    Test();
    void TestCB(const ros::TimerEvent&);
     void getSetSpeedCB(const ros::TimerEvent&);
private:
    geometry_msgs::Vector3 test;
    ros::Publisher pub;
    ros::NodeHandle n;
    ros::Timer timer1,timer2;
    ADRC adrc;
    double v0;
};

Test::Test()
{
    pub = n.advertise<geometry_msgs::Vector3>("car/v1", 1);
    timer1 = n.createTimer(ros::Duration((1.0)/20), &Test::TestCB, this);
    timer2 = n.createTimer(ros::Duration((1.0)/2), &Test::getSetSpeedCB, this);
    v0 = 0;
}

void Test::TestCB(const ros::TimerEvent&)
{
    adrc.TD(v0);        
    test.x = v0;
    test.y = adrc.getV1();
    pub.publish(test);
}
void Test::getSetSpeedCB(const ros::TimerEvent&)
{
    srand(time(NULL));
    int index = rand() % 4;
    v0 = index;
}
int main(int argc, char **argv)
{
    ros::init(argc, argv, "ADRCTest");
    Test test;
    ros::spin();
    return 0;    
}