#!/bin/bash

rosrun map_server map_saver -f  ~/racecar/src/art_racecar/map/mymap
