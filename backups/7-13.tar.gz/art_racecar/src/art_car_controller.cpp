/*
Copyright (c) 2017, ChanYuan KUO, YoRu LU,
latest editor: HaoChih, LIN
All rights reserved. (Hypha ROS Workshop)

This file is part of hypha_racecar package.

hypha_racecar is free software: you can redistribute it and/or modify
it under the terms of the GNU LESSER GENERAL PUBLIC LICENSE as published
by the Free Software Foundation, either version 3 of the License, or
any later version.

hypha_racecar is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU LESSER GENERAL PUBLIC LICENSE for more details.

You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
along with hypha_racecar.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <vector>
#include "ros/ros.h"
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <tf/transform_listener.h>
#include <tf/transform_datatypes.h>
#include "nav_msgs/Path.h"
#include <nav_msgs/Odometry.h>
#include <visualization_msgs/Marker.h>
#include "art_car_controller.hpp"
#include "PID.h"
#include "ADRC.h"

#define PI 3.14159265358979
int start_loop_flag = 0;
int start_speed = 1560;
PID  pid_speed;
using namespace std;

L1Controller::L1Controller()
{
    //Private parameters handler
    ros::NodeHandle pn("~");

    //Car parameter
    pn.param("L", L, 0.26);
    pn.param("Lrv", Lrv, 10.0);
    pn.param("Vcmd", Vcmd, 1.0);
    pn.param("lfw", lfw, 0.13);
    pn.param("lrv", lrv, 10.0);

    //Controller parameter
    pn.param("controller_freq", controller_freq, 20);
    pn.param("AngleGain", Angle_gain, -1.0);
    pn.param("GasGain", Gas_gain, 1.0);
    pn.param("baseSpeed", baseSpeed, 1575);
    pn.param("baseAngle", baseAngle, 90.0);
    pn.param("setTurnAngle", setTurnAngle, 20.0);
    pn.param("turnSpeed", turnSpeed, 1600);
    pn.param("maxDutySpeed", maxDutySpeed, 1660.0);


    //Publishers and Subscribers
    odom_sub = n_.subscribe("/odometry/filtered", 1, &L1Controller::odomCB, this);
    path_sub = n_.subscribe("/move_base/GlobalPlanner/plan", 1, &L1Controller::pathCB, this);
    goal_sub = n_.subscribe("/move_base_simple/goal", 1, &L1Controller::goalCB, this);
    speed_sub = n_.subscribe("/car/speed", 1, &L1Controller::speedCB, this);
    marker_pub = n_.advertise<visualization_msgs::Marker>("car_path", 10);
    pub_ = n_.advertise<geometry_msgs::Twist>("car/cmd_vel", 1);

    //Timer
    timer1 = n_.createTimer(ros::Duration((1.0)/controller_freq), &L1Controller::controlLoopCB, this); // Duration(0.05) -> 20Hz
    timer2 = n_.createTimer(ros::Duration((0.5)/controller_freq), &L1Controller::goalReachingCB, this); // Duration(0.05) -> 20Hz

    //Init variables
    Lfw =  getL1Distance(Vcmd);
    goalRadius = 1.0;
    last_eta = 0, eta = 0;
    foundForwardPt = false;
    goal_received = false;
    goal_reached = false;
    isU = false;
    start_flag=0;//电调是否打开的标志
    cmd_vel.linear.x = 1500; // 1500 for stop
    cmd_vel.angular.z = baseAngle;
    count = 0; //用于计算平均速度

    //Show info
    ROS_INFO("[param] baseSpeed: %d", baseSpeed);
    ROS_INFO("[param] baseAngle: %f", baseAngle);
    ROS_INFO("[param] AngleGain: %f", Angle_gain);
    ROS_INFO("[param] Vcmd: %f", Vcmd);
    ROS_INFO("[param] Lfw: %f", Lfw);
    ROS_INFO("[param] turnSpeed: %d", turnSpeed);
    ROS_INFO("[param] setTurnAngle: %f", setTurnAngle);

    //Visualization Marker Settings
    initMarker();
    //PIDInit(&pid_speed);
   // ADRC adrc;
    car_stop = 0;
    speedSum = 0;
}

void L1Controller::initMarker()
{
    points.header.frame_id = line_strip.header.frame_id = goal_circle.header.frame_id = "odom";
    points.ns = line_strip.ns = goal_circle.ns = "Markers";
    points.action = line_strip.action = goal_circle.action = visualization_msgs::Marker::ADD;
    points.pose.orientation.w = line_strip.pose.orientation.w = goal_circle.pose.orientation.w = 1.0;
    points.id = 0;
    line_strip.id = 1;
    goal_circle.id = 2;

    points.type = visualization_msgs::Marker::POINTS;
    line_strip.type = visualization_msgs::Marker::LINE_STRIP;
    goal_circle.type = visualization_msgs::Marker::CYLINDER;
    // POINTS markers use x and y scale for width/height respectively
    points.scale.x = 0.2;
    points.scale.y = 0.2;

    //LINE_STRIP markers use only the x component of scale, for the line width
    line_strip.scale.x = 0.1;

    goal_circle.scale.x = goalRadius*2;
    goal_circle.scale.y = goalRadius*2;
    goal_circle.scale.z = 0.1;

    // Points are green
    points.color.r = 1.0;
    points.color.a = 1.0;

    // Line strip is blue
    line_strip.color.b = 1.0;
    line_strip.color.a = 1.0;

    //goal_circle is yellow
    goal_circle.color.r = 1.0;
    goal_circle.color.g = 1.0;
    goal_circle.color.b = 0.0;
    goal_circle.color.a = 0.5;
}


void L1Controller::odomCB(const nav_msgs::Odometry::ConstPtr& odomMsg)
{
    odom = *odomMsg;
}


void L1Controller::pathCB(const nav_msgs::Path::ConstPtr& pathMsg)
{
    map_path = *pathMsg;
}

void L1Controller::speedCB(const geometry_msgs::Vector3::ConstPtr& speedMsg)
{
    start_flag = 1;//(*speedMsg).z;
}
void L1Controller::goalCB(const geometry_msgs::PoseStamped::ConstPtr& goalMsg)
{
    try
    {
        geometry_msgs::PoseStamped odom_goal;
        tf_listener.transformPose("odom", ros::Time(0) , *goalMsg, "map" ,odom_goal);//将map上的goal转化到odom
        odom_goal_pos = odom_goal.pose.position;
        goal_received = true;
        goal_reached = false;

        /*Draw Goal on RVIZ*/
        goal_circle.pose = odom_goal.pose;
        marker_pub.publish(goal_circle);
    }
    catch(tf::TransformException &ex)
    {
        ROS_ERROR("%s",ex.what());
        ros::Duration(1.0).sleep();
    }
}

double L1Controller::getYawFromPose(const geometry_msgs::Pose& carPose)
{
    float x = carPose.orientation.x;
    float y = carPose.orientation.y;
    float z = carPose.orientation.z;
    float w = carPose.orientation.w;

    double tmp,yaw;
    tf::Quaternion q(x,y,z,w);
    tf::Matrix3x3 quaternion(q);
    quaternion.getRPY(tmp,tmp, yaw);

    return yaw;
}

// bool L1Controller::isForwardWayPt(const geometry_msgs::Point& wayPt, const geometry_msgs::Pose& carPose)
// {
//     float car2wayPt_x = wayPt.x - carPose.position.x;
//     float car2wayPt_y = wayPt.y - carPose.position.y;
//     double car_theta = getYawFromPose(carPose);

//     float car_car2wayPt_x = cos(car_theta)*car2wayPt_x + sin(car_theta)*car2wayPt_y;
//     float car_car2wayPt_y = -sin(car_theta)*car2wayPt_x + cos(car_theta)*car2wayPt_y;

//     if(car_car2wayPt_x >0) /*is Forward WayPt*/
//         return true;
//     else
//         return false;
// }
bool L1Controller::isForwardPath(const geometry_msgs::Point& car_pos)
{
    double fwdPt_pose_yaw = getYawFromPose(fwdPt_pose);//获取yaw
    geometry_msgs::Point fwdPt2car;
    fwdPt2car.x = cos(fwdPt_pose_yaw)*(car_pos.x - fwdPt_pose.position.x) + sin(fwdPt_pose_yaw)*(car_pos.y - fwdPt_pose.position.y);
    fwdPt2car.y = -sin(fwdPt_pose_yaw)*(car_pos.x - fwdPt_pose.position.x) + cos(fwdPt_pose_yaw)*(car_pos.y - fwdPt_pose.position.y);
    if(fwdPt2car.x < 0) //向前的路径
        return true;
    else
        return false;
}


bool L1Controller::isWayPtAwayFromLfwDist(const geometry_msgs::Point& wayPt, const geometry_msgs::Point& car_pos)
{
    double dx = wayPt.x - car_pos.x;
    double dy = wayPt.y - car_pos.y;
    double dist = sqrt(dx*dx + dy*dy);

    if(dist < Lfw)
        return false;
    else if(dist >= Lfw)
        return true;
}

geometry_msgs::Point L1Controller::get_odom_car2WayPtVec(const geometry_msgs::Pose& carPose)
{
    geometry_msgs::Point carPose_pos = carPose.position;//当前坐标
    double carPose_yaw = getYawFromPose(carPose);//获取yaw
    geometry_msgs::Point forwardPt, endpoint;
    geometry_msgs::Point odom_car2WayPtVec;
    geometry_msgs::Pose thisPose, lastPose;
    double twoPoseAngle;
    foundForwardPt = false; 
    AvgCurvature = 0;
    double sumCurvature = 0; 
    if(!goal_reached)
    {
        for(int i = 0; i< map_path.poses.size(); i++)
        {
            try
            {        
                geometry_msgs::PoseStamped map_path_pose = map_path.poses[i];//路径上的点(map)
                geometry_msgs::PoseStamped odom_path_pose;//路径上的点(odom) 
                tf_listener.transformPose("odom", ros::Time(0) , map_path_pose, "map" ,odom_path_pose);
                geometry_msgs::Point odom_path_wayPt = odom_path_pose.pose.position;
                lastPose = thisPose;
                thisPose = odom_path_pose.pose;               
                if(i > 20)
                {
                    double dx = thisPose.position.x-lastPose.position.x;
                    double dy = thisPose.position.y-lastPose.position.y;
                    double ds = sqrt(dx * dx + dy * dy);
                    twoPoseAngle = getTwoPoseAngle(lastPose, thisPose);
                    sumCurvature += getCurvature(twoPoseAngle, ds);
                    bool _isWayPtAwayFromLfwDist = isWayPtAwayFromLfwDist(odom_path_wayPt,carPose_pos);//判断路径上的点是不是在lfw距离外
                     if(_isWayPtAwayFromLfwDist) //找到前瞻点
                    {
                        fwdPt_pose = odom_path_pose.pose;
                        bool _isForwardPath = isForwardPath(carPose_pos);
                        if(!_isForwardPath)
                            continue;
                        forwardPt = odom_path_wayPt;
                        foundForwardPt = true;
                        AvgCurvature = sumCurvature / (i - 20);
                        break;
                    }
                }

            }
            catch(tf::TransformException &ex)
            {
                ROS_ERROR("%s",ex.what());
                ros::Duration(1.0).sleep();
            }
        }
        
    }
    else if(goal_reached)
    {
        forwardPt = odom_goal_pos;
        foundForwardPt = false;
        //ROS_INFO("goal REACHED!");
    }

    /*Visualized Target Point on RVIZ*/
    /*Clear former target point Marker*/
    points.points.clear();
    line_strip.points.clear();
    
    if(foundForwardPt && !goal_reached)
    {
        points.points.push_back(carPose_pos);
        points.points.push_back(forwardPt);
        points.points.push_back(endpoint);
        line_strip.points.push_back(carPose_pos);
        line_strip.points.push_back(forwardPt);
    }
    
    marker_pub.publish(points);
    marker_pub.publish(line_strip);
    odom_car2WayPtVec.x = cos(carPose_yaw)*(forwardPt.x - carPose_pos.x) + sin(carPose_yaw)*(forwardPt.y - carPose_pos.y);
    odom_car2WayPtVec.y = -sin(carPose_yaw)*(forwardPt.x - carPose_pos.x) + cos(carPose_yaw)*(forwardPt.y - carPose_pos.y);
    return odom_car2WayPtVec;
}


double L1Controller::getEta(const geometry_msgs::Pose& carPose)
{
    geometry_msgs::Point odom_car2WayPtVec = get_odom_car2WayPtVec(carPose);

    double eta = atan2(odom_car2WayPtVec.y,odom_car2WayPtVec.x);
    return eta;
}


double L1Controller::getCar2GoalDist()
{
    geometry_msgs::Point car_pose = odom.pose.pose.position;//车子当前位置
    double car2goal_x = odom_goal_pos.x - car_pose.x;//目标位置－当前位置＝离目标的距离
    double car2goal_y = odom_goal_pos.y - car_pose.y;

    double dist2goal = sqrt(car2goal_x*car2goal_x + car2goal_y*car2goal_y);

    return dist2goal;
}

double L1Controller::getL1Distance(const double& _Vcmd)
{
    double L1 = 0;
    if(_Vcmd < 1.34)
        L1 = 3 / 3.0;
    else if(_Vcmd > 1.34 && _Vcmd < 5.36)
        L1 = _Vcmd*2.24 / 3.0;
    else
        L1 = 12 / 3.0;
    return L1;
}

double L1Controller::getSteeringAngle(double eta)
{
    double steeringAnge = -atan2((L*sin(eta)),(Lfw/2+lfw*cos(eta)))*(180.0/PI);
    //ROS_INFO("Steering Angle = %.2f", steeringAnge);
    return steeringAnge;
}

double L1Controller::getGasInput(const double& setSpeed, const float& current_v)
{
    double u = (setSpeed - current_v)*Gas_gain;
    //ROS_INFO("velocity = %.2f\tu = %.2f",current_v, u);
    return u;
}
void L1Controller::goalReachingCB(const ros::TimerEvent&)
{

    if(goal_received)
    {
        double car2goal_dist = getCar2GoalDist();
        if(car2goal_dist < goalRadius)
        {
            goal_reached = true;
            goal_received = false;
            ROS_INFO("Goal Reached !");
            car_stop = 100;
        }
    }
}

double L1Controller::getfwdPtPose2carPoseAngle(const geometry_msgs::Pose& carPose)
{
    double fwdPt_pose_yaw = getYawFromPose(fwdPt_pose);//fwdPt_pose前瞻点位姿
    double carPose_yaw = getYawFromPose(carPose);
    double fwdPtPose2carPoseAngle = fabs(fwdPt_pose_yaw - carPose_yaw);
    if(fwdPtPose2carPoseAngle > PI)
    {
    	fwdPtPose2carPoseAngle = 2 * PI - fwdPtPose2carPoseAngle;
    }
    return fwdPtPose2carPoseAngle;   //[0,PI]
}

double L1Controller::getSetSpeed(const geometry_msgs::Pose& carPose)
{
    double fwdPtPose2carPoseAngle = getfwdPtPose2carPoseAngle(carPose);
    ROS_INFO("fwdPtPose2carPoseAngle = %.2f", fwdPtPose2carPoseAngle*180/PI);
    double setSpeed;
    if(fabs(fwdPtPose2carPoseAngle) > PI * 2 / 5 || isU)
    {
        isU = true;
        if(fabs(eta) < PI / 10)
            isU = false;
    }
    if(isU)
    {
        setSpeed = 2.0;
        Lfw = getL1Distance(2.5);
        return setSpeed;
    }
    if(fabs(fwdPtPose2carPoseAngle) > PI / 12 && fabs(fwdPtPose2carPoseAngle) <= PI * 2 / 5)
    {
        if(fabs(eta) > PI / 4)
            setSpeed = 2.0;
        else if(AvgCurvature > 0.5)
            setSpeed = 2.5;
        else
            setSpeed = 3.2;
    }
    if(fabs(fwdPtPose2carPoseAngle) <= PI / 12)
    {
        if(fabs(eta) > PI / 4)
            setSpeed = 2.0;
        else if(AvgCurvature > 0.5)
            setSpeed = 2.5;
        else
            setSpeed = 3.2;
    }   
    Lfw = getL1Distance(setSpeed);
    return setSpeed;
}
double L1Controller::getTwoPoseAngle(const geometry_msgs::Pose& pose1, const geometry_msgs::Pose& pose2)
{
    double pose1_yaw = getYawFromPose(pose1);//fwdPt_pose前瞻点位姿
    double pose2_yaw = getYawFromPose(pose2);
    double twoPoseAngle = fabs(pose1_yaw - pose2_yaw);
    if(twoPoseAngle > PI)
    {
    	twoPoseAngle = 2 * PI - twoPoseAngle;    
    }
    return twoPoseAngle;    //[0,PI]
}
double L1Controller::getCurvature(double d_angle,double ds)
{
    double _curvature;
    _curvature = d_angle / ds;
    return _curvature;
}
double L1Controller::getAngleGain()
{
    double AngleGain = 0;
    if(isU)
    {
        AngleGain = -13;
        return AngleGain;
    }      
    if(fabs(eta) > PI / 4)
        AngleGain = -10;
    else
        AngleGain = -8;
    return AngleGain;
}
void L1Controller::controlLoopCB(const ros::TimerEvent&)
{
    geometry_msgs::Pose carPose = odom.pose.pose;
    geometry_msgs::Twist carVel = odom.twist.twist;//单位m/s 

    if(start_flag==0)
    {
    	cmd_vel.linear.x = 1540;
    	cmd_vel.angular.z = baseAngle; 
        pub_.publish(cmd_vel);
    }
    else
    {
        // cmd_vel.linear.x = 1500 + adrc.Calculate(carVel.linear.x,3);//PIDCal(&pid_speed, u, cmd_vel.linear.x);
        // std::cout<<"u = "<<cmd_vel.linear.x-1500<<std::endl;
        // cmd_vel.linear.x = cmd_vel.linear.x > maxDutySpeed ? maxDutySpeed : cmd_vel.linear.x;
        
        if(goal_received)
        {
            /*Estimate Steering Angle*/
            eta = getEta(carPose);  
            double setSpeed = getSetSpeed(carPose);
            Angle_gain = getAngleGain(); 
            cmd_vel.linear.z = setSpeed;
            if(foundForwardPt)
            {               
                cmd_vel.angular.z = baseAngle + getSteeringAngle(eta)*Angle_gain;
                /*Estimate Gas Input*/
                cmd_vel.angular.z = cmd_vel.angular.z > 180 ? 180 : cmd_vel.angular.z;
                cmd_vel.angular.z = cmd_vel.angular.z < 0 ? 0 : cmd_vel.angular.z;
                if(!goal_reached)
                {
                	if(carVel.linear.x > 0)
                	{
                		count ++;
                    	speedSum += carVel.linear.x;
                	}
                    // if(start_loop_flag++ <= 10)
                    // {

                    //     double u = getGasInput(setSpeed,carVel.linear.x);//误差                       
                    //     cmd_vel.linear.x = start_speed;
                    //     start_speed += 4;
                    //     if(cmd_vel.linear.x > baseSpeed)   
                    //         cmd_vel.linear.x = baseSpeed;
                    //     ROS_INFO("baseSpeed = %.2f\tSteering angle = %.2f",cmd_vel.linear.x,cmd_vel.angular.z);
                    // }
                    // else
                    // {
                        double u = getGasInput(setSpeed, carVel.linear.x);                   
                        cmd_vel.linear.x = 1500 + adrc.Calculate(carVel.linear.x,setSpeed);//PIDCal(&pid_speed, u, cmd_vel.linear.x);
                        cmd_vel.linear.x = cmd_vel.linear.x > maxDutySpeed ? maxDutySpeed : cmd_vel.linear.x;
                        /*---------------openLoop------------*/
                        if(u < -0.4)
                        {
                           cmd_vel.linear.x = 1400;
                        }
                        if(u > 0.3)
                        {
                            cmd_vel.linear.x = maxDutySpeed;
                        }                         
                        ROS_INFO("Gas = %.2f\tSteering angle = %.2f\tcurrentSpeed = %.2f\t\teta = %.2f\tsetSpeed = %.2f\tcurvature = %.2f\tAngle_gain = %.2f",
                                        cmd_vel.linear.x,cmd_vel.angular.z,carVel.linear.x,eta*180/PI, setSpeed, AvgCurvature, Angle_gain);
                    // } 
                }
            }
        }
        if(car_stop > 0)//停车
        {
            start_loop_flag = 0;
            double avgSpeed = speedSum/count;
            ROS_INFO("avgSpeed = %.2f", avgSpeed);//平均速度
            if(carVel.linear.x > 0.5)
            {
                cmd_vel.linear.x = 1100; //反向刹车
                pub_.publish(cmd_vel);
            }
            else
            {
                car_stop = 0;
                cmd_vel.linear.x = 1500;
                pub_.publish(cmd_vel);
            }
        }
        else
        {
            pub_.publish(cmd_vel);
            car_stop = 0;
        }
    }
   
}


/*****************/
/* MAIN FUNCTION */
/*****************/
int main(int argc, char **argv)
{
    //Initiate ROS
    ros::init(argc, argv, "art_car_controller");
    L1Controller controller;
    ros::spin();
    return 0;
}
