#include "PID.h"
#include <iostream>
#include <ros/ros.h>
double maxDutySpeed;
void PIDInit (struct PID *pp){
    ros::NodeHandle pn("~");

    pn.param("P",pp->Proportion,15.0);
    pn.param("I",pp->Int,2.0); 
    pn.param("D",pp->Derivative,0.0);
    pn.param("maxDutySpeed",maxDutySpeed,1660.0);       
    pp->LastError = 0;
    pp->PreError = 0;
    pp->intSum = 0;  
    pp->out = 0;              
}

double PIDCal(struct PID *pp, double ThisError, double dutySpeed){ 
    ROS_INFO("ThisError = %.2f\tLastError = %.2f",ThisError, pp->LastError);
    /*---------变速积分---------------*/
    double intFactor;
    if(fabs(ThisError) > 2.0)
    {
        intFactor = 0;
    }
    else if(fabs(ThisError) <= 2.0 && fabs(ThisError) > 1.8)
    {
        intFactor = (2.0 - fabs(ThisError)) / 0.2;
    }
    else
    {
        intFactor = 1;
    }

    /*-----------积分抗饱和-----------------*/
    if(dutySpeed >= maxDutySpeed && ThisError < 0)
    {
        pp->intSum += ThisError;
    }
    if(dutySpeed <= 1500 && ThisError >0)
    {
        pp->intSum += ThisError;
    }
    if(dutySpeed < maxDutySpeed && dutySpeed >1500)
    {
        pp->intSum += ThisError;
    }
    /*-----------积分限幅------------------*/
    pp->intSum = pp->intSum > 150 ? 150 : pp->intSum;
    pp->intSum = pp->intSum < -150 ? -150 : pp->intSum;
    ROS_INFO("intSum=%.2f",pp->intSum);
    pp->out = pp->Proportion * ThisError + intFactor * pp->Int * pp->intSum + pp->Derivative * (ThisError - pp->LastError);
    
    ROS_INFO("out=%.2f",pp->out);
    pp->LastError = ThisError; 
    return pp->out;
}
