/********************/
/* CLASS DEFINITION */
/********************/
class L1Controller
{
    public:
        L1Controller();
        void initMarker();
        //bool isForwardWayPt(const geometry_msgs::Point& wayPt, const geometry_msgs::Pose& carPose);
        bool isWayPtAwayFromLfwDist(const geometry_msgs::Point& wayPt, const geometry_msgs::Point& car_pos);
        double getYawFromPose(const geometry_msgs::Pose& carPose);        
        double getEta(const geometry_msgs::Pose& carPose);
        double getCar2GoalDist();
        double getL1Distance(const double& _Vcmd);
        double getSteeringAngle(double eta);
        double getGasInput(const double& setSpeed, const float& current_v);
        geometry_msgs::Point get_odom_car2WayPtVec(const geometry_msgs::Pose& carPose);

    private:
        ros::NodeHandle n_;
        ros::Subscriber odom_sub, path_sub, goal_sub,speed_sub;
        ros::Publisher pub_, marker_pub;
        ros::Timer timer1, timer2;
        tf::TransformListener tf_listener;

        visualization_msgs::Marker points, line_strip, goal_circle;
        geometry_msgs::Twist cmd_vel;
        geometry_msgs::Point odom_goal_pos;
        nav_msgs::Odometry odom;
        nav_msgs::Path map_path, odom_path;

        double L, Lfw, Lrv, Vcmd, lfw, lrv, steering, u, v, eta, last_eta, turn_coe;
        double Gas_gain, baseAngle, Angle_gain, goalRadius,setTurnAngle;
        int controller_freq, baseSpeed,turnSpeed;
        bool foundForwardPt, goal_received, goal_reached;
        int car_stop,start_flag;
        geometry_msgs::Pose fwdPt_pose;//前瞻点的位姿
        int count;
        double speedSum;
        double maxDutySpeed;

        void odomCB(const nav_msgs::Odometry::ConstPtr& odomMsg);
        void pathCB(const nav_msgs::Path::ConstPtr& pathMsg);
        void speedCB(const geometry_msgs::Vector3::ConstPtr& speedMsg);
        void goalCB(const geometry_msgs::PoseStamped::ConstPtr& goalMsg);
        void goalReachingCB(const ros::TimerEvent&);
        void controlLoopCB(const ros::TimerEvent&);
        double getSetSpeed(const geometry_msgs::Pose& carPose);
        double getfwdPtPose2carPoseAngle(const geometry_msgs::Pose& carPose);
        bool isForwardPath(const geometry_msgs::Point& car_pos);
}; // end of class

