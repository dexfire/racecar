#include "PID.h"
#include <iostream>
#include <ros/ros.h>
double maxDutySpeed, minDutySpeed;
void PIDInit (struct PID *pp){
    ros::NodeHandle pn("~");

    pn.param("P1",pp->Proportion1,15.0);
    pn.param("P2",pp->Proportion2,15.0);
    pn.param("I",pp->Int,2.0); 
    pn.param("D",pp->Derivative,0.0);
    pn.param("maxDutySpeed",maxDutySpeed,1660.0);
    pn.param("minDutySpeed",minDutySpeed,1200.0);         
    pp->LastError = 0;
    pp->PreError = 0;
    pp->intSum = 0;  
    pp->out = 0;              
}

double PIDCal(struct PID *pp, double ThisError, double dutySpeed){ 
    ROS_INFO("ThisError = %.2f\tLastError = %.2f",ThisError, pp->LastError);
    /*---------变速积分---------------*/
    double intFactor;
    if(fabs(ThisError) > 2.9)
    {
        intFactor = 0;
    }
    else if(fabs(ThisError) <= 2.9 && fabs(ThisError) > 2.7)
    {
        intFactor = (2.9 - fabs(ThisError)) / 0.2;
    }
    else
    {
        intFactor = 1;
    }

    /*-----------积分抗饱和-----------------*/
    if(dutySpeed >= maxDutySpeed - 20 && ThisError < 0)
    {
        pp->intSum += intFactor * ThisError;
    }
    if(dutySpeed <= 1500 && ThisError >0)
    {
        pp->intSum += intFactor * ThisError;
    }
    if(dutySpeed <= maxDutySpeed && dutySpeed >= minDutySpeed)
    {
        pp->intSum += intFactor * ThisError;
    }
    /*-----------积分限幅------------------*/
    pp->intSum = pp->intSum > 150 ? 150 : pp->intSum;
    pp->intSum = pp->intSum < -150 ? -150 : pp->intSum;
    ROS_INFO("intSum=%.2f",pp->intSum);
    if(ThisError - pp->LastError > 0)
        pp->out = pp->Proportion1 * ThisError + pp->Int * pp->intSum + pp->Derivative * (ThisError - pp->LastError);
    else
        pp->out = pp->Proportion2 * ThisError + pp->Int * pp->intSum + pp->Derivative * (ThisError - pp->LastError);
    ROS_INFO("out=%.2f",pp->out);
    pp->LastError = ThisError; 
    return pp->out;
}
